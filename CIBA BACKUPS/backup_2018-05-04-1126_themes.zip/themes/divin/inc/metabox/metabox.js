jQuery(document).ready(function(){
	jQuery("#divin-ui-tabs").tabs()
});
