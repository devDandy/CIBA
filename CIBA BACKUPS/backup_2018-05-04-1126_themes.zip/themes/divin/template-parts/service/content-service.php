<?php
/**
 * The template used for displaying service
 *
 * @package Divin
 */
?>

<?php
/**
 * divin_service hook
 * @hooked divin_service_display - 10
 */
do_action( 'divin_service' );
