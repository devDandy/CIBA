<?php
/**
 *
 * @package anissa
 */

get_header(); ?>
<?php woocommerce_content(); ?>
<?php get_footer(); ?>