<?php
/**
 * The sidebar containing the main widget areas.
 *
 * @package anissa
 */
?>

<div id="secondary" class="widget-area sidebar" role="complementary">
  <?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>
<!-- #secondary -->