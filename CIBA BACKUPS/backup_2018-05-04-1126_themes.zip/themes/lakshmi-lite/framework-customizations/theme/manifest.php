<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['id'] = 'lakshmi-lite';

$manifest['supported_extensions'] = array(
	'megamenu' => array(),
	'backups' => array(),
	'sidebars' => array(),
	'page-builder' => array(),
	'seo' => array(),
	'analytics' => array(),
	'slider' => array(),
	'wp-shortcodes' => array(),
);

