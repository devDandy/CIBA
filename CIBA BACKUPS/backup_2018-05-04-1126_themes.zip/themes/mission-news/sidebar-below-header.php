<?php if ( is_active_sidebar( 'below-header' ) ) : ?>
	<aside class="widget-area widget-area-below-header" id="below-header" role="complementary">
		<?php dynamic_sidebar( 'below-header' ); ?>
	</aside>
<?php endif;