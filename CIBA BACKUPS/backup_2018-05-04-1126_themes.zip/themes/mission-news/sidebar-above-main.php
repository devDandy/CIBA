<?php if ( is_active_sidebar( 'above-main' ) ) : ?>
	<aside class="widget-area widget-area-above-main" id="above-main" role="complementary">
		<?php dynamic_sidebar( 'above-main' ); ?>
	</aside>
<?php endif;