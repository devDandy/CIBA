<nav class="further-reading">
	<div class="previous">
		<span><?php previous_image_link( false, esc_html__( 'Previous Image', 'mission-news' ) ); ?></span>
	</div>
	<div class="next">
		<span><?php next_image_link( false, esc_html__( 'Next Image', 'mission-news' ) ); ?></span>
	</div>
</nav>